
import React, { useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import Hero from '@/components/home/Hero';
import { AuthContext } from '@/main';

const Index = () => {
  const { isAuthenticated, userRole } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    // If authenticated, redirect to the appropriate dashboard
    if (isAuthenticated) {
      if (userRole === 'customer') {
        navigate('/lists');
      } else if (userRole === 'store') {
        navigate('/dashboard');
      }
    }
  }, [isAuthenticated, userRole, navigate]);

  return (
    <Layout>
      <Hero />
    </Layout>
  );
};

export default Index;
