
import React from 'react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      number: 1,
      title: 'Create Your List',
      description: 'Add items, specify quantities and preferred brands',
      color: 'bg-secondary'
    },
    {
      number: 2,
      title: 'Share & Collaborate',
      description: 'Family members can add items or make changes',
      color: 'bg-accent'
    },
    {
      number: 3,
      title: 'Submit to Store',
      description: 'Send your completed list to the store',
      color: 'bg-primary'
    },
    {
      number: 4,
      title: 'Wait for Packing',
      description: 'Store owner packs items and marks unavailable ones',
      color: 'bg-secondary'
    },
    {
      number: 5,
      title: 'Pay & Pick Up',
      description: 'Pay via QR code and collect your groceries',
      color: 'bg-accent'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">How GrocerEase Works</h2>
          <p className="text-lg text-gray-600">
            A simple 5-step process to make your grocery shopping effortless
          </p>
        </div>
        
        <div className="relative">
          {/* Connecting line */}
          <div className="absolute top-24 left-0 right-0 h-0.5 bg-gray-200 hidden md:block"></div>
          
          <div className="grid md:grid-cols-5 gap-8">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <div className="flex flex-col items-center text-center">
                  <div className={`${step.color} w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mb-5 shadow-lg z-10`}>
                    {step.number}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
