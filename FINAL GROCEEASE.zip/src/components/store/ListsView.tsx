import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { useStoreLists } from '@/hooks/use-store-lists';
import { ShoppingList } from '@/lib/firestore';

const ListsView = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { lists, loading, error } = useStoreLists();
  const [selectedList, setSelectedList] = useState<ShoppingList | null>(null);

  const handleViewList = (list: ShoppingList) => {
    setSelectedList(list);
  };

  const handleGoBack = () => {
    setSelectedList(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-600">
        <p>Error loading lists: {error}</p>
      </div>
    );
  }

  if (selectedList) {
    return (
      <div className="w-full max-w-full">
        <div className={`flex ${isMobile ? 'flex-col items-start' : 'items-center justify-between'} mb-6 w-full gap-2`}>
          <Button variant="outline" size="sm" onClick={handleGoBack} className="mb-2">
            &larr; Back to Lists
          </Button>
          
          <div className={`flex ${isMobile ? 'flex-col items-start' : 'items-center justify-between'} w-full`}>
            <h2 className={`${isMobile ? 'text-lg' : 'text-xl'} font-semibold`}>
              List: {selectedList.name}
            </h2>
            <div className="mt-2">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                selectedList.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                selectedList.status === 'processing' ? 'bg-orange-100 text-orange-800' :
                selectedList.status === 'ready' ? 'bg-green-100 text-green-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {selectedList.status.charAt(0).toUpperCase() + selectedList.status.slice(1)}
              </span>
            </div>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader className="py-4">
            <CardTitle className={`${isMobile ? 'text-base' : 'text-lg'}`}>List Information</CardTitle>
          </CardHeader>
          <CardContent className="py-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <p className="text-sm font-medium text-gray-500">Created</p>
                <p>{selectedList.createdAt.toDate().toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Last Updated</p>
                <p>{selectedList.updatedAt.toDate().toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <h3 className={`${isMobile ? 'text-base' : 'text-lg'} font-medium mb-4`}>List Items</h3>
        <div className="space-y-4">
          {selectedList.items.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{item.name}</h4>
                    <p className="text-sm text-gray-500">
                      {item.quantity} • Brand: {item.brand}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {lists.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingBag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">No Lists Yet</h3>
          <p className="text-gray-500">No shopping lists have been submitted to your store yet.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>List Name</TableHead>
                <TableHead className={isMobile ? "hidden" : ""}>Created</TableHead>
                <TableHead className={isMobile ? "hidden" : ""}>Items</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lists.map((list) => (
                <TableRow key={list.id}>
                  <TableCell className="font-medium">{list.name}</TableCell>
                  <TableCell className={isMobile ? "hidden" : ""}>{list.createdAt.toDate().toLocaleDateString()}</TableCell>
                  <TableCell className={isMobile ? "hidden" : ""}>{list.items.length} items</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      list.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                      list.status === 'processing' ? 'bg-orange-100 text-orange-800' :
                      list.status === 'ready' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {list.status.charAt(0).toUpperCase() + list.status.slice(1)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewList(list)}
                    >
                      <Edit size={16} /> {isMobile ? "" : "View"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default ListsView; 