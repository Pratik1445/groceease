import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ShoppingList } from '@/lib/firestore';
import Image from 'next/image';

interface BillGeneratorProps {
  list: ShoppingList;
  onGenerateBill: (totalAmount: number) => Promise<void>;
  open: boolean;
  onClose: () => void;
}

const BillGenerator = ({ list, onGenerateBill, open, onClose }: BillGeneratorProps) => {
  const [totalAmount, setTotalAmount] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!totalAmount) return;

    await onGenerateBill(parseFloat(totalAmount));
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Generate Bill for {list.name}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Total Amount</label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="Enter total amount"
              value={totalAmount}
              onChange={(e) => setTotalAmount(e.target.value)}
              required
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Generate Bill
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BillGenerator; 